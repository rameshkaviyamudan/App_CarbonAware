package com.sp.loginregisterfirebases;
public class FoodSelection {
    private boolean beefSelected;
    private boolean muttonSelected;
    private boolean seafoodSelected;
    private boolean eggsSelected;
    private boolean grainsSelected;
    private boolean dairySelected;
    private boolean fruitsSelected;
    private boolean vegetablesSelected;

    // Add additional fields for more food items
    private boolean chickenSelected;
    private boolean porkSelected;
    // ...

    // Setters and getters for the fields
    public boolean isBeefSelected() {
        return beefSelected;
    }

    public void setBeefSelected(boolean beefSelected) {
        this.beefSelected = beefSelected;
    }

    public boolean isMuttonSelected() {
        return muttonSelected;
    }

    public void setMuttonSelected(boolean muttonSelected) {
        this.muttonSelected = muttonSelected;
    }

    public boolean isSeafoodSelected() {
        return seafoodSelected;
    }

    public void setSeafoodSelected(boolean seafoodSelected) {
        this.seafoodSelected = seafoodSelected;
    }

    public boolean isEggsSelected() {
        return eggsSelected;
    }

    public void setEggsSelected(boolean eggsSelected) {
        this.eggsSelected = eggsSelected;
    }

    public boolean isGrainsSelected() {
        return grainsSelected;
    }

    public void setGrainsSelected(boolean grainsSelected) {
        this.grainsSelected = grainsSelected;
    }

    public boolean isDairySelected() {
        return dairySelected;
    }

    public void setDairySelected(boolean dairySelected) {
        this.dairySelected = dairySelected;
    }

    public boolean isFruitsSelected() {
        return fruitsSelected;
    }

    public void setFruitsSelected(boolean fruitsSelected) {
        this.fruitsSelected = fruitsSelected;
    }

    public boolean isVegetablesSelected() {
        return vegetablesSelected;
    }

    public void setVegetablesSelected(boolean vegetablesSelected) {
        this.vegetablesSelected = vegetablesSelected;
    }

    // Add setters and getters for additional fields
    public boolean isChickenSelected() {
        return chickenSelected;
    }

    public void setChickenSelected(boolean chickenSelected) {
        this.chickenSelected = chickenSelected;
    }

    public boolean isPorkSelected() {
        return porkSelected;
    }

    public void setPorkSelected(boolean porkSelected) {
        this.porkSelected = porkSelected;
    }

    // ...

}
