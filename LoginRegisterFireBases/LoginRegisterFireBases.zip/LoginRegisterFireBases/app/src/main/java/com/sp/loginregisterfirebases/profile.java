package com.sp.loginregisterfirebases;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import android.widget.TextView;



public class profile extends AppCompatActivity {
    private TextView pname;
    private TextView ppassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        // Load the BottomNavigationFragment
        BottomNavigationFragment bottomNavigationFragment = BottomNavigationFragment.newInstance("param1", "param2");
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, bottomNavigationFragment);
        fragmentTransaction.commit();
        // Retrieve the user's first name and number from the intent extras
        String firstName = getIntent().getStringExtra("firstname");
        String password = getIntent().getStringExtra("password");

        // Bind the data to the TextViews in the profile layout
        pname = findViewById(R.id.pname);
        ppassword = findViewById(R.id.ppassword);

        pname.setText(firstName);
        ppassword.setText(password);


    }
}
