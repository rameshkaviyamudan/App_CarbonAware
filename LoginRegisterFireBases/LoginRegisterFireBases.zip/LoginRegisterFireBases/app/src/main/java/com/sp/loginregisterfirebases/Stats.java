package com.sp.loginregisterfirebases;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
public class Stats extends AppCompatActivity {
    private ViewPager2 viewpager;
    private List<StatData> statList;
    private int volleyResponseStatus;
    private int currentCategoryIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stats_activity);
        getSupportActionBar().setDisplayShowTitleEnabled(true); // Show the title

        viewpager = findViewById(R.id.viewpager);
        // Create the GraphPagerAdapter with this activity as the fragment host
        GraphPagerAdapter graphPagerAdapter = new GraphPagerAdapter(this);
        viewpager.setAdapter(graphPagerAdapter);

        statList = new ArrayList<>();
        // Set up the ViewPager2.OnPageChangeCallback
        viewpager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);

                // Update currentCategoryIndex based on the selected page position
                if (position == 0) {
                    currentCategoryIndex = 1;
                    Toast.makeText(getApplicationContext(), " evvv", Toast.LENGTH_SHORT).show();

                } else if (position == 1) {
                    currentCategoryIndex = 0;
                    Toast.makeText(getApplicationContext(), "Error updating row", Toast.LENGTH_SHORT).show();

                }
            }
        });
        retrieveStatData();

        // Load the BottomNavigationFragment
        BottomNavigationFragment bottomNavigationFragment = BottomNavigationFragment.newInstance("param1", "param2");
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, bottomNavigationFragment);
        fragmentTransaction.commit();

    }
    private ViewPager2.OnPageChangeCallback onPageChangeCallback = new ViewPager2.OnPageChangeCallback() {
        @Override
        public void onPageSelected(int position) {
            currentCategoryIndex = position;
        }
    };

    private void retrieveStatData() {
        viewpager.registerOnPageChangeCallback(onPageChangeCallback);

        SharedPreferences sharedPreferences = getSharedPreferences("MyfirPrefs", MODE_PRIVATE);
        String firstname = sharedPreferences.getString("firstname", "");

        String params = "?where={\"firstname\": {\"$eq\":[\"" + firstname + "\"]}}";
        String url = VolleyHelper.carburl + params;

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            int count = response.getInt("count");
                            JSONArray data = response.getJSONArray("data");

                            if (count > 0) {
                                JSONObject row = data.getJSONObject(0);

                                // Retrieve your stat data from the database
                                float homeCarbonFootprint = (float) row.getDouble("home_carbon_footprint");
                                float foodCarbonFootprint = (float) row.getDouble("food_carbon_footprint");
                                float travelCarbonFootprint = (float) row.getDouble("travel_carbon_footprint");
                                float totalCarbonFootprint = (float) row.getDouble("total_carbon_footprint");


                                StatData userStatData = new StatData(homeCarbonFootprint, foodCarbonFootprint, travelCarbonFootprint, totalCarbonFootprint);

// Pass the userStatData object to the GraphFragments
                                Bundle bundle = new Bundle();
                                bundle.putParcelable("userStatData", userStatData);;

                                GraphFragment1 fragment1 = new GraphFragment1();
                                fragment1.setArguments(bundle);

                                GraphFragment2 fragment2 = new GraphFragment2();
                                fragment2.setArguments(bundle);

                                GraphFragment3 fragment3 = new GraphFragment3();
                                fragment3.setArguments(bundle);

                                GraphFragment4 fragment4 = new GraphFragment4();
                                fragment4.setArguments(bundle);

                                // Now, add the fragments to the ViewPager
                                List<Fragment> fragments = new ArrayList<>();
                                fragments.add(fragment1);
                                fragments.add(fragment2);
                                fragments.add(fragment3);
                                fragments.add(fragment4);
                                // Pass the FragmentManager and Lifecycle to the adapter
                                CustomFragmentStateAdapter fragmentStateAdapter = new CustomFragmentStateAdapter(getSupportFragmentManager(), getLifecycle(), fragments);                                viewpager.setAdapter(fragmentStateAdapter);
                            } else {
                                Toast.makeText(getApplicationContext(), "No record found. Please enter records to view your carbon footprint.", Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error retrieving row", Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return VolleyHelper.getHeader();
            }

            @Override
            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                volleyResponseStatus = response.statusCode;
                return super.parseNetworkResponse(response);
            }
        };

        queue.add(jsonObjectRequest);
    }

}