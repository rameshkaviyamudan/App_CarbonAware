package com.sp.loginregisterfirebases;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {
    EditText firstname;
    EditText password;
    Button login;
    Button signupbtn;
    private int volleyResponseStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        firstname = findViewById(R.id.name);
        password = findViewById(R.id.pword);
        login = findViewById(R.id.login);
        signupbtn = findViewById(R.id.signupbtn);
        login.setOnClickListener(onLogin);
        signupbtn.setOnClickListener(onSignUp);
    }

    View.OnClickListener onLogin = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Log.d("Login", "Login button clicked");
            String name_input = firstname.getText().toString();
            String password_input = password.getText().toString();
            getByUserNamePasswordVolley(name_input, password_input);
        }
    };
    View.OnClickListener onSignUp = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(Login.this, Register.class);
            startActivity(intent);
        }
    };




    // Get a record using the current ID
    private void getByUserNamePasswordVolley(String firstnameStr, String passwordStr) {
        String params = "?where={\"firstname\": {\"$eq\":[\"" +firstnameStr+"\"]}, \"password\" : {\"$eq\":[\""+passwordStr+"\"]}}";
        String url = VolleyHelper.loginurl + params; //Query by username and password
        RequestQueue queue = Volley.newRequestQueue(this);
        // Use GET REST api call
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        if (volleyResponseStatus == 200) { // Read successfully from database
                            try {
                                int count = response.getInt("count"); //Number of records from database
                                if (count > 0) {
                                    Intent intent = new Intent(Login.this, MainActivity.class);
                                    intent.putExtra("firstname", firstnameStr);
                                    intent.putExtra("password", passwordStr);
                                    startActivity(intent);
                                    // Use the retrieved username as needed
                                    Toast.makeText(getApplicationContext(), "Firstname: " + firstnameStr, Toast.LENGTH_SHORT).show();
                                    // Store the username in SharedPreferences
                                    SharedPreferences sharedfirPreferences = getSharedPreferences("MyfirPrefs", MODE_PRIVATE);
                                    SharedPreferences.Editor editor = sharedfirPreferences.edit();
                                    editor.putString("firstname", firstnameStr);
                                    editor.apply();
                                } else {
                                    Toast.makeText(getApplicationContext(),"Login Fail", Toast.LENGTH_LONG).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error
                        Log.e("OnErrorResponse", error.toString());
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return VolleyHelper.getHeader();
            }

            @Override
            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                volleyResponseStatus = response.statusCode;
                return super.parseNetworkResponse(response);
            }
        };
        // add JsonObjectRequest to the RequestQueue
        queue.add(jsonObjectRequest);
    }
}
